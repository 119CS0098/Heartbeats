<?php
  session_start();
  // if(!isset($_SESSION['username'])){
  //         header("Location:login.php");
  //   }
?>

<!DOCTYPE html>

<html data-wf-page="5e7780539a2d8322cd989658" data-wf-site="56d8a8f1100bc1bb7928eebd">

<head>
    <meta charset="utf-8" />
    <title>Heartbeats</title>
    <link href="https://assets.website-files.com/56d8a8f1100bc1bb7928eebd/css/heco.webflow.63a162681.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style>
        @media (min-width:992px) {
            html.w-mod-js:not(.w-mod-ix) [data-w-id="4e046d2a-ea16-4d41-6c26-f14d3012e2a8"] {
                -webkit-transform: translate3d(0, -20PX, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);
                -moz-transform: translate3d(0, -20PX, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);
                -ms-transform: translate3d(0, -20PX, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);
                transform: translate3d(0, -20PX, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);
                opacity: 0;
                display: none;
            }
        }

        @media (max-width:991px) and (min-width:768px) {
            html.w-mod-js:not(.w-mod-ix) [data-w-id="4e046d2a-ea16-4d41-6c26-f14d3012e2a8"] {
                -webkit-transform: translate3d(0, -20PX, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);
                -moz-transform: translate3d(0, -20PX, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);
                -ms-transform: translate3d(0, -20PX, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);
                transform: translate3d(0, -20PX, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);
                opacity: 0;
                display: none;
            }
        }
    </style>

    <style type="text/css">.bg-bios {
        background-image: url("bg.jpg");
        background-size: cover;
    }</style>

    <style type="text/css">
    	.box {
		   position: absolute;
		  transform: translate(-50%, -50%);
		  border-radius: 25px;
			}

		.box select {
		  background-color: #fff;
		  color: dimgrey;
		  padding: 10px;
		  width: 250px;
		  border: none;
		  font-size: 20px;
		  box-shadow: 0 5px 25px rgba(0, 0, 0, 0.2);
		  -webkit-appearance: button;
		  appearance: button;
		  outline: none;
		}

		/*.box::before {
		  content: "\f13a";
		  font-family: Ubuntu;
		  position: absolute;
		  top: 0;
		  right: 0;
		  width: 20%;
		  height: 100%;
		  text-align: center;
		  font-size: 28px;
		  line-height: 45px;
		  color: rgba(255, 255, 255, 0.5);
		  background-color: rgba(255, 255, 255, 0.1);
		  pointer-events: none;
		}*/

		.box:hover::before {
		  color: rgba(255, 255, 255, 0.6);
		  background-color: rgba(105,105,105);
		}

		.box select option {
		  padding: 30px;
		}
    </style>

    <style type="text/css">

    	.link-button-arrow {
        position: absolute;
        left: 0px;
        margin-top: 80px;
        margin-left: 200px;
        padding: 10px 25px 10px 25px ;
        font-color:#fff;
        border-color: #4e4e4e;
         background-color: #fff;
    }</style>

    <script src="https://ajax.googleapis.com/ajax/libs/webfont/1.6.26/webfont.js" type="text/javascript"></script>
    <script type="text/javascript">
        WebFont.load({
            google: {
                families: ["Source Sans Pro:300,regular,600", "Source Sans Pro:200,300,regular"]
            }
        });
    </script>
   
    <script type="text/javascript">
        ! function(o, c) {
            var n = c.documentElement,
                t = " w-mod-";
            n.className += t + "js", ("ontouchstart" in o || o.DocumentTouch && c instanceof DocumentTouch) && (n.className += t + "touch")
        }(window, document);
    </script>
    
    <script type="text/javascript">
        var _gaq = _gaq || [];
        _gaq.push(['_setAccount', 'UA-88246775-1'], ['_trackPageview']);
        (function() {
            var ga = document.createElement('script');
            ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(ga, s);
        })();
    </script>
    <meta name="theme-color" content="#000000">

    <style>
        body {
            overflow-x: hidden;
        }

        .w-container,
        .about-testimonial-block {
            max-width: 1200px;
        }

        .container-project-img,
        .container-project-text,
        .footer-container {
            max-width: 1100px;
        }

        /*
	.w-container.container-work {
		max-width: 960px;
	}
*/

        video::-webkit-media-controls-start-playback-button {
            display: none !important;
        }

        .no-bg {
            background-color: transparent !important;
            background-image: none !important;
            overflow: hidden !important;
        }

        .backgrounds>div {
            transform: scale(1.03);
            transform: translate3d(0, 0, 0);
            -webkit-transform: translate3d(0, 0, 0);
            -webkit-backface-visibility: hidden;
        }

        .project-thumb {
            -webkit-backface-visibility: hidden;
        }
    </style>
    <style>
        /* Base */

        .mimg{
            width: 200px;
        }

        #awwwards {
            position: absolute;
            bottom: 20px;
            width: 90px;
            height: 135px;
            text-indent: -666em;
            overflow: hidden;
            z-index: 999;
            -webkit-transition: all 1s ease;
            transition: all 1s ease;
        }

        #awwwards.top {
            top: 0;
        }

        #awwwards.left {
            left: 0;
        }

        #awwwards.right {
            right: 0;
        }

        #awwwards a {
            position: absolute;
            top: 0;
            left: 0;
            display: block;
            width: 90px;
            height: 135px;
            background-repeat: no-repeat;
            background-size: 90px 135px;
        }

        /* HONORABLE */

        #awwwards.sotd.white.right a {
            background-image: url(https://s30.postimg.org/42v5ue5nh/awwwards_sotd_white_right.png);
        }

        @media only screen and (-Webkit-min-device-pixel-ratio: 1.5),
        only screen and (-moz-min-device-pixel-ratio: 1.5),
        only screen and (-o-min-device-pixel-ratio: 3/2),
        only screen and (min-device-pixel-ratio: 1.5) {
            #awwwards.sotd.white.right a {
                background-image: url(https://s30.postimg.org/4453nt7h9/awwwards_sotd_white_right_2x.png);
            }
        }

        #bodybox {
          margin: auto;
          max-width: 550px;
          font: 15px arial, sans-serif;
          background-color: white;
          border-style: solid;
          border-width: 1px;
          padding-top: 20px;
          padding-bottom: 25px;
          padding-right: 25px;
          padding-left: 25px;
          box-shadow: 5px 5px 5px grey;
          border-radius: 15px;
        }

        #chatborder {
          border-style: solid;
          background-color: #f6f9f6;
          border-width: 3px;
          margin-top: 20px;
          margin-bottom: 20px;
          margin-left: 20px;
          margin-right: 20px;
          padding-top: 10px;
          padding-bottom: 15px;
          padding-right: 20px;
          padding-left: 15px;
          border-radius: 15px;
        }

        .chatlog {
           font: 15px arial, sans-serif;
        }

        #chatbox {
          font: 17px arial, sans-serif;
          height: 22px;
          width: 100%;
        }
    </style>

</head>

<body>
    <div data-ix="preloader" class="preloader-container">
        <div class="preloader-wavy"></div>
    </div>
    <div class="backgrounds">
        <div class="bg-footer"></div>
        <div class="bg-clients"></div>
        <div class="bg-studio"></div>
        <div class="bg-capabilities"></div>
        <div class="bg-bios"></div>
        <div class="bg-work"></div>
        <div class="bg-aboutus"></div>
        <div data-autoplay="true" data-loop="true" data-wf-ignore="true" data-poster-url="https://assets.website-files.com/56d8a8f1100bc1bb7928eebd/58458c90a39ccfdb4c175922_HECO_LINE_ANIMATION_v04-poster-00001.jpg" data-video-urls="https://assets.website-files.com/56d8a8f1100bc1bb7928eebd/58458c90a39ccfdb4c175922_HECO_LINE_ANIMATION_v04-transcode.mp4,https://assets.website-files.com/56d8a8f1100bc1bb7928eebd/58458c90a39ccfdb4c175922_HECO_LINE_ANIMATION_v04-transcode.webm"
            class="bg-intro w-background-video w-background-video-atom"><video autoplay="" loop="" style="background-image:url(&quot;https://assets.website-files.com/56d8a8f1100bc1bb7928eebd/58458c90a39ccfdb4c175922_HECO_LINE_ANIMATION_v04-poster-00001.jpg&quot;)" muted="" playsinline="" data-wf-ignore="true" data-object-fit="cover"><source src="https://assets.website-files.com/56d8a8f1100bc1bb7928eebd/58458c90a39ccfdb4c175922_HECO_LINE_ANIMATION_v04-transcode.mp4" data-wf-ignore="true"/><source src="https://assets.website-files.com/56d8a8f1100bc1bb7928eebd/58458c90a39ccfdb4c175922_HECO_LINE_ANIMATION_v04-transcode.webm" data-wf-ignore="true"/></video></div>
    </div>
    <img src="1.svg" width="150px" height="100px" style="position: absolute; left: 40px; top: 40px;">
    <a href="index.php" class="link-contact w-inline-block">
        <div class="link-wavy link-wavy-header"><h1>Logout</h1></div>
    </a>
    <div class="next-prev-container">
        <div class="next-block">
            <div data-ix="next-prev-btn" class="w-dyn-list">
                <div role="list" class="w-dyn-items">
                    <div role="listitem" class="w-dyn-item"><a href="/project/oliv" data-ix="next-prev-btn" data-w-id="4098f3fe-d7f0-4438-503d-d17894cde30c" style="-webkit-transform:translate3d(0, 0, 0) scale3d(0, 0, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-moz-transform:translate3d(0, 0, 0) scale3d(0, 0, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-ms-transform:translate3d(0, 0, 0) scale3d(0, 0, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);transform:translate3d(0, 0, 0) scale3d(0, 0, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);opacity:0"
                            class="next-btn home w-inline-block"><img src="https://assets.website-files.com/56d8a8f1100bc1bb7928eebd/582dfe50c34982e54bfea896_icon-next-prev-arrow.svg" style="-webkit-transform:translate3d(-50%, -50%, 0) scale3d(1, 1, 2) rotateX(0) rotateY(0) rotateZ(90DEG) skew(0, 0);-moz-transform:translate3d(-50%, -50%, 0) scale3d(1, 1, 2) rotateX(0) rotateY(0) rotateZ(90DEG) skew(0, 0);-ms-transform:translate3d(-50%, -50%, 0) scale3d(1, 1, 2) rotateX(0) rotateY(0) rotateZ(90DEG) skew(0, 0);transform:translate3d(-50%, -50%, 0) scale3d(1, 1, 2) rotateX(0) rotateY(0) rotateZ(90DEG) skew(0, 0);transform-style:preserve-3d" alt="" class="next-arrow"/><div class="hover-circle home"></div></a></div>
                </div>
            </div>
            <div href="index.php" data-w-id="0835d1ab-4cca-5aeb-be24-a0b244d9d415" style="opacity:0;-webkit-transform:translate3d(-30PX, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-moz-transform:translate3d(-30PX, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);-ms-transform:translate3d(-30PX, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0);transform:translate3d(-30PX, 0, 0) scale3d(1, 1, 1) rotateX(0) rotateY(0) rotateZ(0) skew(0, 0)"
                class="next-prev-text">Want to chat?</div>
        </div>
    </div>
    <div data-ix="home-intro" id="intro" class="section-intro no-bg">
        <div data-ix="text-fades" class="header-message w-container">
            <h1 class="overview">We suggest songs according to your mood and help you out as a friend.</h1>
            <div data-ix="home-scroll-arrow" class="down-arrow"></div>
        </div>
    </div>
    <div data-ix="home-aboutus" id="aboutus" class="section-aboutus no-bg">
        <div class="container-padding container-aboutus w-container">
            <p data-ix="text-fades" class="p-aboutus">Heartbeats is a music web app that specializes in <a href="#work" class="link-wavy link-wavy-light">suggesting</a> music to calm your soul . We also provide special <a href="#bio-jt" class="link-wavy link-wavy-light">rooms</a>, to help you contemplate and make you feel fresh. We bring together experience that is <a href="#capabilities" class="link-wavy link-wavy-light">heavenly</a> to help our <a href="#clients" class="link-wavy link-wavy-light">users</a>                clear their blocked minds.</p>
        </div>
    </div>
    <div data-ix="home-aboutus" id="aboutus" class="section-aboutus no-bg">
        <div class="container-padding container-aboutus w-container">
            <p data-ix="text-fades" class="p-aboutus">Heartbeats is a music web app that specializes in <a href="#work" class="link-wavy link-wavy-light">suggesting</a> music to calm your soul . We also provide special <a href="#bio-jt" class="link-wavy link-wavy-light">rooms</a>, to help you contemplate and make you feel fresh. We bring together experience that is <a href="#capabilities" class="link-wavy link-wavy-light">heavenly</a> to help our <a href="#clients" class="link-wavy link-wavy-light">users</a>                clear their blocked minds.</p>
        </div>
    </div>
    <div data-ix="home-work" id="work" data-w-id="5bc678a0-2c47-d352-562c-79bb0f61c538" class="section-work no-bg">
        <div data-w-id="b344bf64-cd53-81de-270b-0083ba7a2c74" class="container-work w-container">
            <div class="work-left-column w-dyn-list">
                <div role="list" class="w-clearfix w-dyn-items">
                    <div role="listitem" class="w-dyn-item"><a href="/project/oliv" data-ix="project-list-thumb" class="home-work-item w-inline-block"><img src="1.jpg" class="project-thumb"/><audio src="1.mp3" controls></audio><h4 class="work-title">Meditation space</h4><h4 class="project-description">Breathe in and breathe out while enjoying this soothing music.</h4></a></div>
                    <div
                        role="listitem" class="w-dyn-item"><a href="/project/blueboard" data-ix="project-list-thumb" class="home-work-item w-inline-block"><img src="3.jpg" alt="Blueboard" sizes="(max-width: 479px) 81vw, 44vw" class="project-thumb"/><audio src="3.mp3" controls></audio><h4 class="work-title">Relaxing Space</h4><h4 class="project-description">Relax to live a healthy life. Have confidence.</h4></a></div>
                <div
                    role="listitem" class="w-dyn-item"><a href="/project/oncorps" data-ix="project-list-thumb" class="home-work-item w-inline-block"><img src="5.jpg" sizes="(max-width: 479px) 81vw, 44vw" class="project-thumb"/><audio src="5.mp3" controls></audio><h4 class="work-title">Dancing Space</h4><h4 class="project-description">Make the world dance to your tunes while we make you dance to ours.</h4></a></div>
          
    </div>
    </div>
    <div class="work-left-column right-column w-dyn-list">
        <div role="list" class="w-clearfix w-dyn-items">
            <div role="listitem" class="w-dyn-item"><a href="/project/bluecrew" data-ix="project-list-thumb" class="home-work-item w-inline-block"><img src="2.jpg" sizes="(max-width: 479px) 81vw, 44vw" class="project-thumb"/><h4 class="work-title"><audio src="2.mp3" controls></audio><h4 class="work-title">Sleeping Space</h4><h4 class="project-description">Sleeping helps to relieve you from all the sorrows. Sleep well.</h4></a></div>
            <div
                role="listitem" class="w-dyn-item"><a href="/project/hub-on-campus" data-ix="project-list-thumb" class="home-work-item w-inline-block"><img src="4.jpg" class="project-thumb"/><audio src="4.mp3" controls></audio><h4 class="work-title">Romantic Space</h4><h4 class="project-description">Stir up your life with a little extra love from us.</h4></a></div>
        <div
            role="listitem" class="w-dyn-item"><a href="/project/cyrus-hotel" data-ix="project-list-thumb" class="home-work-item w-inline-block"><img src="6.jpg" sizes="(max-width: 479px) 81vw, 44vw"  class="project-thumb"/><audio src="6.mp3" controls></audio><h4 class="work-title">Party Space</h4><h4 class="project-description">You don't need to get into a pub to be in a party. What's your plan tonight?</h4></a></div>
   
        </div>
        </div>
        </div>
        </div>
        <div data-ix="home-bios" class="section-bios no-bg">
            <div class="container-bios-new w-container">
                <div class="bio-logo-container"><a href="#bio-jt" class="w-inline-block"><img src="3.svg" alt="" class="logo-bio-he" style="display:none" /></a><a href="#bio-matt" class="w-inline-block"><img src="4.svg" alt="" class="logo-bio-co" style="display:none"/></a></div>
                <div
                    class="bio-sine-container">
                    <div class="bio-sine-mask">
                        <div class="bio-sine"></div>
                    </div>
            </div>
            <input type="hidden" id='hidden_token'>
            <div class="bio-p-container">
                <div class="box bio-p-he" >
						  <select id="select_genre">
						  <option>Select Genres</option>
						  </select>
				</div>
				<div class="box bio-p-co">
						  <select id="select_playlist">
						  <option>Select Playlists</option>
						  </select>
				</div>
				<div class="bio-p-co"><a data-ix="background" class="link-button-arrow" id="btn_submit">Search</a></div>
            </div>
        </div>

        <div data-ix="bio-he" id="bio-jt" class="bio-container w-container"></div>
        <div data-ix="bio-co" id="bio-matt" class="bio-container w-container"></div>

        <div class="row">
                        <div class="offset-sm-1 col-sm-6 px-0">
                            <div class="list-group song-list">
                                
                            </div>                                             
                        </div>
                        <div class="offset-md-1 col-sm-4" id="song-detail">                
                        </div>
                    </div>

       
        </div>
        
         <div id='bodybox' style="margin-top: 100px; background-image: url('bg.jpg');">
          <h1></h1>  
          <div id='chatborder'>
            <p id="chatlog7" class="chatlog">&nbsp;</p>
            <p id="chatlog6" class="chatlog">&nbsp;</p>
            <p id="chatlog5" class="chatlog">&nbsp;</p>
            <p id="chatlog4" class="chatlog">&nbsp;</p>
            <p id="chatlog3" class="chatlog">&nbsp;</p>
            <p id="chatlog2" class="chatlog">&nbsp;</p>
            <p id="chatlog1" class="chatlog">&nbsp;</p>
            <input type="text" name="chat" id="chatbox" placeholder="Hi there! Type here to talk to me." onfocus="placeHolder()">
          </div>
          <br>
          <br>
        </div>  

        <div data-ix="home-footer" class="section-footer no-bg">
            <div class="container-padding w-container">
                <p data-ix="home-footer-text-fades" class="p-footer">If you want an evening to relax you and calm you then definitely we are here to help you with some amazing music suggestion, <a href="mailto:info@heartbeats.com" class="link-wavy link-wavy-light">get in touch</a>.<br/></p>
            </div>
            <div class="footer-details">
                <div class="footer-left">
                    <div class="footer-text">Designed by SB</div>
                </div>
                <div class="footer-mid">
                    <a href="mailto:info@heartbeats.com" class="footer-link w-inline-block">
                        <div>info@heartbeats.com</div>
                    </a>
                </div>
                <div class="footer-right">
                    <a target="_blank" class="social-link footer-link w-inline-block">
                        <div>twitter</div>
                    </a>
                    <a  target="_blank" class="w-inline-block">
                        <div class="social-link footer-link">facebook</div>
                    </a>
                    <a  target="_blank" class="w-inline-block">
                        <div class="footer-link">instagram</div>
                    </a>
                </div>
            </div>
        </div>
        <script src="https://d3e54v103j8qbb.cloudfront.net/js/jquery-3.5.1.min.dc5e7f18c8.js?site=56d8a8f1100bc1bb7928eebd" type="text/javascript" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
        <script src="https://assets.website-files.com/56d8a8f1100bc1bb7928eebd/js/webflow.c23b36f35.js" type="text/javascript"></script>
        
        <script>
            $(function() {
                var x = 0;
                setInterval(function() {
                    x -= 1;
                    $(".preloader-wavy, .link-wavy:hover, .project-copy a:hover").css('background-position', x + 'px 100%');
                }, 20);
            })
        </script>
        <div id="awwwards" class="sotd white right">
            <a href="http://www.awwwards.com" target="_blank">Awwwards</a>
        </div>
        <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="app.js" type="text/javascript"></script>
    <script>
        //links
        //http://eloquentjavascript.net/09_regexp.html
        //https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Regular_Expressions


        var messages = [], //array that hold the record of each string in chat
          lastUserMessage = "", //keeps track of the most recent input string from the user
          botMessage = "", //var keeps track of what the chatbot is going to say
          botName = 'Chatbot', //name of the chatbot
          talking = true; //when false the speach function doesn't work
        //
        //
        //****************************************************************
        //****************************************************************
        //****************************************************************
        //****************************************************************
        //****************************************************************
        //****************************************************************
        //****************************************************************
        //edit this function to change what the chatbot says
        function chatbotResponse() {
          talking = true;
          botMessage = "I'm confused"; //the default message

          if (lastUserMessage === 'hi' || lastUserMessage =='hello') {
            const hi = ['hi','howdy','hello']
            botMessage = hi[Math.floor(Math.random()*(hi.length))];;
          }

          if (lastUserMessage === 'name') {
            botMessage = 'My name is ' + botName;
          }

          if (lastUserMessage === 'depressed' || lastUserMessage === 'suicide') {
            // botMessage = 'I’m really sorry you’re going through this. I’m here for you if you need me. I suggest you to spend some time with nature or listen to music';
            botMessage = 'I’m really sorry you’re going through this. I’m here for you if you need me. I suggest you to spend some time with nature or listen to music.<br>Let me know how do you feel now<form action="twilio/send.php"><button type="submit">Sad</button><button type="submit">Depressed</button><button type="submit">Suicidal</button></form>';
          }
        }
        //****************************************************************
        //****************************************************************
        //****************************************************************
        //****************************************************************
        //****************************************************************
        //****************************************************************
        //****************************************************************
        //
        //
        //
        //this runs each time enter is pressed.
        //It controls the overall input and output
        function newEntry() {
          //if the message from the user isn't empty then run 
          if (document.getElementById("chatbox").value != "") {
            //pulls the value from the chatbox ands sets it to lastUserMessage
            lastUserMessage = document.getElementById("chatbox").value;
            //sets the chat box to be clear
            document.getElementById("chatbox").value = "";
            //adds the value of the chatbox to the array messages
            messages.push(lastUserMessage);
            //Speech(lastUserMessage);  //says what the user typed outloud
            //sets the variable botMessage in response to lastUserMessage
            chatbotResponse();
            //add the chatbot's name and message to the array messages
            messages.push("<b>" + botName + ":</b> " + botMessage);
            // says the message using the text to speech function written below
            Speech(botMessage);
            //outputs the last few array elements of messages to html
            for (var i = 1; i < 8; i++) {
              if (messages[messages.length - i])
                document.getElementById("chatlog" + i).innerHTML = messages[messages.length - i];
            }
          }
        }

        //text to Speech
        //https://developers.google.com/web/updates/2014/01/Web-apps-that-talk-Introduction-to-the-Speech-Synthesis-API
        function Speech(say) {
          if ('speechSynthesis' in window && talking) {
            var utterance = new SpeechSynthesisUtterance(say);
            //msg.voice = voices[10]; // Note: some voices don't support altering params
            //msg.voiceURI = 'native';
            //utterance.volume = 1; // 0 to 1
            //utterance.rate = 0.1; // 0.1 to 10
            //utterance.pitch = 1; //0 to 2
            //utterance.text = 'Hello World';
            //utterance.lang = 'en-US';
            speechSynthesis.speak(utterance);
          }
        }

        //runs the keypress() function when a key is pressed
        document.onkeypress = keyPress;
        //if the key pressed is 'enter' runs the function newEntry()
        function keyPress(e) {
          var x = e || window.event;
          var key = (x.keyCode || x.which);
          if (key == 13 || key == 3) {
            //runs this function when enter is pressed
            newEntry();
          }
          if (key == 38) {
            console.log('hi')
              //document.getElementById("chatbox").value = lastUserMessage;
          }
        }

        //clears the placeholder text ion the chatbox
        //this function is set to run when the users brings focus to the chatbox, by clicking on it
        function placeHolder() {
          document.getElementById("chatbox").placeholder = "";
        }

    </script>
</body>

</html>