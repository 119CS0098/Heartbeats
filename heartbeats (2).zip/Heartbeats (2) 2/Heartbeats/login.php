<?php
  session_start();
?>

<!DOCTYPE html>
<html>
<head>
  <title>Login</title>
  <link href='https://fonts.googleapis.com/css?family=Ubuntu:500' rel='stylesheet' type='text/css'>
  <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet'>
  <link rel="stylesheet" type="text/css" href="login.css">
</head>
<body>
  <div class="login">
  
  <form class="login-form" method="POST" action="login.php" style="background-color:white; border-radius: 20px;">
      <div class="login-header">
        <h1 style="color:#354463;">LOGIN</h1>
      </div>
      <h3>Username:</h3>
      <input type="text" placeholder="E-mail" name="email" id="email"/><br>
      <h3>Password:</h3>
      <input type="password" placeholder="Password" name="password" id="password"/>
      <br>
      <input type="submit" value="Login" class="login-button" name="login1" id="submit" style="width:80%; background-image: linear-gradient(to right, #354463 ,  black);"/>
      <br>
  </form>
<?php  
  include_once 'dbh.php';

  if(isset($_POST['login1'])){
    $email = $_POST['email'];
    $password = md5($_POST['password']);

    $query = "SELECT * FROM admin WHERE email = '$email' AND password = '$password'";

    $result = mysqli_query($conn,$query);

    $check = mysqli_num_rows($result);

    $row = mysqli_fetch_assoc($result);

    if($check>0){
      $_SESSION['username'] = $row['username'];
      header('location: index2.php');
    }
    else{
      echo '<script type="text/javascript">alert("Incorrect Details")</script>';
    }
  }

?>
</div>
</body>
</html>




